function masUno(arr) {
  debugger;
  return arr.map(item => item + 1)
}