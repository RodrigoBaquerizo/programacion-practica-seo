// String
const ejemplo = 'Esto es un texto';

const minus = ejemplo.toLowerCase() 

const arr = ejemplo.split(' ')

const rpl = ejemplo.replace('texto','ejemplo')

// Arrays

const inc = arr.includes('ejemplo') // false

const largo = arr.length // 4

const duplicated = arr.slice(3)

arr.splice(0,2)

arr.push('de')

const last = arr.pop()

arr.unshift('Esto')

Array.from()

Array.isArray(arr)
