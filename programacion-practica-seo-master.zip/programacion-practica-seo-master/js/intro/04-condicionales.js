if (condicion) {
  // se ejecuta si la condición se cumple
} else {
  // se ejecuta si la condición no se cumple
}

if (condicion1) {
  if (condicion2) {

  }
}

if (condicion1) {
  // se ejecuta si la condición1 se cumple
} else if (condicion2) {
  // se ejecuta si la condición2 se cumple
} else {
  // se ejecuta si la condición1 y la condición2 no se cumple
}


if(x > y && y > z) {

} else if (x > y || y > z) {

}

condicion ? 'si se cumple condicion me ejecuto' : 'si no se cumple condición me ejecuto'


