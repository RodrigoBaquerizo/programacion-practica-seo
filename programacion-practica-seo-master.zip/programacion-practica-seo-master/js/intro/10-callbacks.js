// Callbacks
const mostrar = element => {
  console.log(element);
};

array.forEach(mostrar);