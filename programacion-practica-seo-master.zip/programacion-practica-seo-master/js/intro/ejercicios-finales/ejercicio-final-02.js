// 2. Añade un parámetro a la función para poder pasarle un listado de stopwords. 
//   slugify(texto, ['de','que','los'])
//   Ejemplos:
//   * ' que significan los sueños' --> '/significan-suenos'
//   * 'qué hacer después de programar' --> '/hacer-despues-programar'