// 3. He guardado el archivo `urls-ejercicio-final-03` en una variable para poder trabajar con el.
//   Vamos a:
//   * Localizar cuantos tipos de valores existen en el atributo `robots` y sumar cuantos hay de cada uno
//   * Encuentra que slug tiene como valor en el robots: `aqui tenía que haber otra cosa no? :P`
//   * Contabiliza cuantas urls se pueden indexar y cuantas no

// En esta variable `listaDeUrls` esta el archivo cargado, haz un console.log para ver que contiene ^^
console.log(listaDeUrls)

// * Localizar cuantos tipos de valores existen en el atributo `robots` y sumar cuantos hay de cada uno


//   * Encuentra que slug tiene como valor en el robots: `aqui tenía que haber otra cosa no? :P`


//   * Contabiliza cuantas urls se pueden indexar y cuantas no

