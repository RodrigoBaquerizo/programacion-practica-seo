const suma = 5 + 5

let s = 1 + 2
s++ // (1+2) + 1 = 4

const resta = 5 - 5

let r = 1 - 1
r-- // (1 - 1) - 1  = -1

const division = 5 / 5

const multiplicacion = 5 * 5

const resto = 5 % 5

const e = 5 ** 5

const mayorQue = 1 > 6 // false

const menorQue = 1 < 2 // true

const igualQue = 1 == '1' // Igualdad del valor --> true
const igualque2 = 1 === '1' // igualdad del valor y del tipo --> false

1 && 2 // AND

true || false // OR

