
const lista = [1,2,3,4]

const arr = [1, 'texto', "texto", true, {}]

const arr2d =[
  [1,2,3],
  [4,5,6],
  [1,2]
]

lista[0] // 1

lista[lista.length() - 1] // 4

arr2d[0] // [1,2,3]
arr2d[0][1] // 1