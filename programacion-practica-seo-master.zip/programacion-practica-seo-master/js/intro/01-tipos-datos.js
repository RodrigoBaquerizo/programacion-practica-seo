// string
"cadena de texto"
'ejemplo de texto'
`ejemplo de texto`

// number
43
6
728289272

// boolean
true
false

// null
null

// undefined
undefined

// object
{

}

// object (array)
[

]

