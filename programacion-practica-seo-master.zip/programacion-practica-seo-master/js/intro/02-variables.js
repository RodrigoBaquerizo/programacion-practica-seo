// Function scoped
var texto = 'texto de ejemplo';


// ES6 
// Block Scoped

// Constante
const q = 'otro texto mas';

// Puede ser reasignado
let ejemplo = 1;
ejemplo = 2;
