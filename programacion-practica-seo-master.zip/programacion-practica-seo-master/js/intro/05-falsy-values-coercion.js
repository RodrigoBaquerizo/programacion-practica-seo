// falsy values
false, 0, -0, '', null, undefined, NaN

6 * "TEXTO" //NaN

//coercion
!!0 // false
!!null // false

! // Not

!0 // true