const miObjeto = {
  nombre: 'nacho',
  edad: 28,
  conPerro: false,
  ordenadores: [
    'mac',
    'pc'
  ],
  otroObj: {
    otroMas: {
      //
    }
  }
}

miObjeto.nombre // nacho
miObjeto.edad // 28
miObjeto.otroObj.otroMas 

miObjeto.extra = 'si'
// JSON: Javascript Object Notation