# Ejercicios finales JS intermedio
  1. Promisifica la función de fs.readFile para poder acceder a archivos a través de promesas. (Importante hacer el ejercicio de consultar la documentación primero y sino buscarlo en Google).

  2. Con la función promisificada, importala y consulta el archivo ejercicio.csv. Para hacerlo crea una función llamada read() y exportala

  3. Importa la función anterior y parsea el csv usando un modulo de node (https://www.npmjs.com/package/neat-csv) y haz todo el proceso de instalación, require y ejecución con el objetivo final de mostrarlo en consola.
  