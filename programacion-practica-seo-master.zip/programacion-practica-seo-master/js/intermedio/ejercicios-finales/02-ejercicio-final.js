// 2. Con la función promisificada, importala y consulta el archivo ejercicio. 
// Para hacerlo crea una función llamada read() y exportala

