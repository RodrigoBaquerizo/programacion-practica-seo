// 3. Importa la función anterior y parsea el csv usando un modulo de node 
// (https://www.npmjs.com/package/neat-csv) y haz todo el proceso de instalación, 
// require y ejecución con el objetivo final de mostrarlo en consola.
