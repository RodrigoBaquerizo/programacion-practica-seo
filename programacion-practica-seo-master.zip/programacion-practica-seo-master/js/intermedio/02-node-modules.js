// https://www.npmjs.com/

// https://nodejs.org/docs/latest-v12.x/api/

// https://nodejs.org/docs/latest-v12.x/api/fs.html

const fs = require('fs');

