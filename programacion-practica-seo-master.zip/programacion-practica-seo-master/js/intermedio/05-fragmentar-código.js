// importar de otro archivo
const inputObj = require('./03-leer-archivos').inputObj;


// exportar de forma global 
module.exports = {
  inputObj
}