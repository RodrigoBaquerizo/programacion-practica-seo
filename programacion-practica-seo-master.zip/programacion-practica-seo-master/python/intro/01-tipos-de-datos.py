# bool, True or False
True
False

# float
3.874748

# int, integers
2
3
4

# str, strings
'cadena de texto'

# range
range(6) # 0,1,2,3,4,5

range(10) # 0,1,2,3,4,5,6,7,8,9

# list
[1,2,3,4]


# tuple
('movil', 'pc')

# dict
{
  'a': 'lo que sea',
  'b': 'otro valor'
}

# set
{1,2,3,4}

# None
None
