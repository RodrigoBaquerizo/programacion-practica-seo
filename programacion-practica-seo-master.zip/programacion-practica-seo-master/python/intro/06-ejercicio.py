# Ejercicio 01 Comprueba que valor es mayor, si valor1 o valor2. Puedes modificar los valores desde el formulario que permite realizar Colab.
# Usa condicionales para saber que valor es mayor, menor o igual

# Ejercicio resuelto --> https://colab.research.google.com/drive/1s05hvW53Jz3URwMgylqwzG6cnXa4-DVe#scrollTo=Rc-TDB0JfSjP
