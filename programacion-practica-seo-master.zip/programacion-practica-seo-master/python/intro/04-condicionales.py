
x = 3
y = 1

if x > y:
  print('x es mayor que y')
elif x < y:
  print('y es mayor que x')
else:
  print('x es igual a y')