ejemploLista =[1,2,3,4]

# # for
for variableEjemplo in ejemploLista:
  print(variableEjemplo)

# range
for i in range(6):
  print(i)

# while
while x > 3:
  print(x)
else:
  x = 3


# break
for z in range(1000):
  print(z)
  if z == 10:
    break


# continue
for z in range(15):
  if z == 10:
    continue
  print(z)

