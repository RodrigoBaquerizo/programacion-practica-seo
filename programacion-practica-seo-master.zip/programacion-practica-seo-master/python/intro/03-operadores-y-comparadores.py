suma = 5 + 5

s = 1 + 2
s += 1 # (1+2) + 1 = 4


resta = 5 - 5

r = 1 - 1
r -= 1 # (1 - 1) - 1 = -1

division = 5 / 5

multiplicacion = 5 * 5

resto = 5 % 5

e = 5 ** 5

floor = 5 // 2 #2


mayorQue = 1 >= 6 # false

menorQue = 1 < 2 # true

igualQue = 1 == '1' # Igualdad del valor y tipo--> false


1 and 2

true or false 

not True ## Similar al ! de JS
