None

False

0, 0.0, ...

'' () [] {}

