from fragmentado import pedir_edad

pedir_edad()