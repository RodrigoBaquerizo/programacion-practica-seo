# Ejercicios finales de Python intermedio

1. Crea un script que abra un listado de páginas al ejecutarse
2. Vamos a modificar el módulo spintax y añadirle la funcionalidad de generar textos ilimitados
3. Crear un script para extraer tendencias de Google --> pytrends