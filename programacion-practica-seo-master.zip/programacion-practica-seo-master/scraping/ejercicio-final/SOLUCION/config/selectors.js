module.exports = {
  parent: 'div.rc',
  elements: {
    textContent: {
      title: 'a h3'
    },
    href: {
      url: 'div.yuRUbf > a'
    }
  }
}