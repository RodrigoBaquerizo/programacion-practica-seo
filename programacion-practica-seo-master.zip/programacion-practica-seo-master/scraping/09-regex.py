# Generar RegEx
import re

r = re.compile('plo')

# Métodos
print(r.search('ejemplo'))
print(r.findall('ploejemploejemplo'))