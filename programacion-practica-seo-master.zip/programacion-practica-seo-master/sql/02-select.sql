SELECT * 
FROM crawl;

SELECT 
    Address,
    Status_Code
FROM crawl;

SELECT 
        address AS URL,
    Status_Code AS statusCode
FROM crawl;